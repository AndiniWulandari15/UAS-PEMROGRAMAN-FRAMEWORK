<?php 

	$koneksi = mysqli_connect('localhost','root','','lapakberkah');

	new mysqli ();

	if (! $koneksi){
	echo 'Maaf, Koneksi gagal. silahkan coba lagi.';
	}

?>