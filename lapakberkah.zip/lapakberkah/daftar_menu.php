<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="index.css">

    <title>Lapak Berkah</title>
  </head>
  <body>
  <!-- Jumbotron -->
      <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
          <h1 class="display-4"><span class="font-weight-bold">LAPAK BERKAH</span></h1>
          <hr>
          <p class="lead font-weight-bold">Silahkan Pesan Menu Sesuai Keinginan Anda <br> 
          Enjoy Your Meal</p>
        </div>
      </div>
  <!-- Akhir Jumbotron -->

  <!-- Navbar -->
      <nav class="navbar navbar-expand-lg  bg-dark">
        <div class="container">
        <a class="navbar-brand text-white" href="index.php"><strong>LAPAK</strong> BERKAH</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link mr-4" href="index.php">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="daftar_menu.php">DAFTAR MENU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="pesanan.php">GAMBAR MENU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="pesanan.php">PESANAN</a>
            </li>
            
          </ul>
        </div>
       </div> 
      </nav>
  <!-- Akhir Navbar -->

  <!-- Menu -->
        <br>
      
  <!-- Akhir Menu -->
   <div class="container">
      <div class="judul-pesanan mt-5
      \">
       
        <h3 class="text-center font-weight-bold">DATA DAFTAR MENU</h3>
        
      </div>
    <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th><center>No</center></th>
                <th><center>Kd Menu</center></th>
                <th><center>Nama Menu</center></th>
                <th><center>Harga</center></th>
                <th><center>Aksi</center></th>
              </tr>
            </thead>
            <tbody>
  <?php
      
      include 'koneksi.php';
      $no = 1;
      $sql = "SELECT * FROM menu";

      $result = mysqli_query($koneksi, $sql);

      while ($data = mysqli_fetch_assoc($result)) {

      ?>
        <tr>
          <td><?php echo $no++ ?></td>
          <td><?php echo $data['kd_menu'] ?></td>
          <td><?php echo $data['nama'] ?></td>
          <td><?php echo $data['harga'] ?></td>
           
          <td>
            <center>
            <a href="tambah_menu.php" class="btn btn-primary">Tambah</a>
            <a href="hapus_menu.php?kd_menu=<?php echo $data['kd_menu'] ?>"><button type="button" class="btn btn-warning">Hapus</button></a>
            </center>
          </td>
        </tr>
      <?php } ?>

    </tbody>
  </table>

  <!-- Awal Footer -->
      <hr class="footer">
      <div class="container">
        <div class="row footer-body">
          <div class="col-md-6">
          
          </div>
        </div>
      </div>
    </div>
  <!-- Akhir Footer -->
  </body>
</html>