-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2022 at 04:40 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lapakberkah`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `kd_menu` int(11) NOT NULL COMMENT 'Kode Menu',
  `nama` varchar(30) NOT NULL COMMENT 'Nama Menu',
  `harga` varchar(15) NOT NULL COMMENT 'Harga Menu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`kd_menu`, `nama`, `harga`) VALUES
(101, 'Bakso', 'Rp.12.000'),
(102, 'Mie Ayam', 'Rp.12.000'),
(103, 'Nasi Goreng', 'Rp.10.000'),
(104, 'Mie Ayam Bakso', 'Rp.15.000'),
(105, 'Lele Bakar', 'Rp.14.000'),
(106, 'Teh Obeng', 'Rp.5.000'),
(107, 'Jus Alpukat', 'Rp.8.000'),
(108, 'Es Jeruk', 'Rp.7.000'),
(109, 'Air Minum Sanford', 'Rp.3.000'),
(110, 'Nasi Putih', 'Rp.2.000'),
(111, 'Jus Mangga', 'Rp.6.000'),
(112, 'Ayam Bakar', 'Rp.17.000');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `kd_pesanan` int(11) NOT NULL COMMENT 'Kode Pesanan',
  `no_meja` int(11) NOT NULL COMMENT 'Nomor Meja',
  `nama_pesanan` varchar(45) NOT NULL COMMENT 'Nama Pesanan',
  `jumlah` int(11) NOT NULL COMMENT 'Jumlah Pesanan',
  `tanggal` date NOT NULL COMMENT 'Tanggal Pesanan',
  `status` varchar(20) NOT NULL COMMENT 'Status Pemesanan'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`kd_pesanan`, `no_meja`, `nama_pesanan`, `jumlah`, `tanggal`, `status`) VALUES
(201, 1, 'Bakso', 2, '2022-06-16', 'Bayar'),
(203, 3, 'Jus Alpukat', 4, '2022-06-15', 'Bayar'),
(205, 0, 'Mie Ayam', 2, '2022-06-20', 'Belum Bayar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kd_menu`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`kd_pesanan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
