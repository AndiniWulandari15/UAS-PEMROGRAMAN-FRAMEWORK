<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="index.css">

    <title>Lapak Berkah</title>
  </head>
  <body>
  <!-- Jumbotron -->
      <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
          <h1 class="display-4"><span class="font-weight-bold">LAPAK BERKAH</span></h1>
          <hr>
          <p class="lead font-weight-bold">Silahkan Pesan Menu Sesuai Keinginan Anda <br> 
          Enjoy Your Meal</p>
        </div>
      </div>
  <!-- Akhir Jumbotron -->

  <!-- Navbar -->
      <nav class="navbar navbar-expand-lg  bg-dark">
        <div class="container">
        <a class="navbar-brand text-white" href="index.php"><strong>LAPAK</strong> BERKAH</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link mr-4" href="index.php">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="daftar_menu.php">DAFTAR MENU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="gambar_menu.php">GAMBAR MENU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="pesanan.php">PESANAN</a>
            </li>
            
          </ul>
        </div>
       </div> 
      </nav>
  <!-- Akhir Navbar -->

  <!-- Menu -->
        <br>
      
  <!-- Akhir Menu --><?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
	$kdPesanan = $_POST['kd_pesanan'];
  $noMeja = $_POST['no_meja'];
	$namaPesanan = $_POST['nama_pesanan'];
	$jumlah		= $_POST['jumlah'];
  $tanggal = $_POST['tanggal'];
  $status = $_POST['status'];
	

	$queryMysql = "INSERT INTO pesanan (kd_pesanan, no_meja, nama_pesanan, jumlah, tanggal, status) VALUES ('$kdPesanan','$noMeja', '$namaPesanan', '$jumlah', '$tanggal', '$status')";

	$simpanData = mysqli_query($koneksi, $queryMysql);

	if ($simpanData) {
		header("location: pesanan.php") ;
	} else {
		echo 'data gagal disimpan';
	}
}

?>
<div class="container">
      <div class="judul-pesanan mt-5
      \">
        
      </div>
<div class="col-md10 p-5 pt-2">
<div class="alert alert-primary">
	<h3 href="tambah_menu.php" class="text-center">TAMBAH DAFTAR PESANAN</h3>
</div>
<form method="POST" action="" class="form-group">
	<div class="mb-2 row">
		<label for="inputnama" class="col-sm-2 col-form-label">Kd Pesanan</label>
		<div class="col-sm-4">
			<input type="text" name="kd_pesanan" placeholder="Masukkan kode pesanan" size="80" class="form-control" />
		</div>
	</div>

  <div class="mb-2 row">
    <label for="inputnama" class="col-sm-2 col-form-label">No Meja</label>
    <div class="col-sm-4">
      <input type="text" name="no_meja" placeholder="Masukkan nomor meja" size="80" class="form-control" />
    </div>
  </div>

	<div class="mb-2 row">
		<label for="inputnama" class="col-sm-2 col-form-label">Nama Pesanan</label>
		<div class="col-sm-4">
			<input type="text" name="nama_pesanan" placeholder="Masukkan nama pesanan" size="80" class="form-control" />
		</div>
	</div>

	<div class="mb-2 row">
		<label for="inputnama" class="col-sm-2 col-form-label">Jumlah</label>
		<div class="col-sm-4">
			<input type="text" name="jumlah" placeholder="Masukkan Jumlah" size="35" class="form-control" />
		</div>
	</div>

  <div class="mb-2 row">
    <label for="inputnama" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-4">
      <input type="text" name="tanggal" placeholder="Masukkan Tanggal Pemesanan" size="35" class="form-control" />
    </div>
  </div>

  <div class="mb-2 row">
    <label for="inputnama" class="col-sm-2 col-form-label">Status</label>
    <div class="col-sm-4">
      <input type="text" name="status" placeholder="Masukkan Status Pemesanan" size="35" class="form-control" />
    </div>
  </div>

	<br /><br />

	<input name="simpan" type="submit" value="Simpan Data" class="btn btn-outline-info" />
</form>
</div>
</div>
</body>
</html>