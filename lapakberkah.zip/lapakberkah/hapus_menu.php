<?php

	require_once('koneksi.php');

	$querySql	= "DELETE FROM menu WHERE kd_menu = '$_GET[kd_menu]'";
	
	$deleteData = mysqli_query($koneksi, $querySql);
	
	if($deleteData)
		
	{			
		header("location: daftar_menu.php");
	}
?>