<?php

	require_once('koneksi.php');

	$querySql	= "DELETE FROM pesanan WHERE kd_pesanan = '$_GET[kd_pesanan]'";
	
	$deleteData = mysqli_query($koneksi, $querySql);
	
	if($deleteData)
		
	{			
		header("location: pesanan.php");
	}
?>